# iOS_Akash_MidTermProject


# News Break
News Break allows you to read news from the United States. The features of this app can be broken down into steps.:
1. After you enter the app, you will be able to see all of the news.
2. You can view news by category.
3. You can Bookmark news to read later.
4. You can also delete bookmark news.
5. You can search various news.
6. Pull to refresh will refresh the app with new news.
7. Clicking on the news will allow you to read briefly. 

## Screenshots

![App Screenshot](https://i.postimg.cc/DyHSYD3B/Apple-i-Phone-11-Pro-Max-Screenshot-0.png)
![App Screenshot](https://i.postimg.cc/mrXkC6jY/Apple-i-Phone-11-Pro-Max-Screenshot-1.png)
![App Screenshot](https://i.postimg.cc/QdjdPrng/Apple-i-Phone-11-Pro-Max-Screenshot-2.png)
![App Screenshot](https://i.postimg.cc/T32T0JpC/Apple-i-Phone-11-Pro-Max-Screenshot-3.png)

