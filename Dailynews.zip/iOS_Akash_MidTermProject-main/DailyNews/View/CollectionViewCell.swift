//
//  CollectionViewCell.swift
//  DailyNews
//
//  Created by BJIT on 13/1/23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var categoryLabel: UILabel!
    
    @IBOutlet weak var categoryView: UIView!
    
    
}
