//
//  Category.swift
//  DailyNews
//
//  Created by BJIT on 13/1/23.
//

import Foundation

class Category{
    static var category = ["General","Business", "Entertainment", "Health","Sports", "Science", "Technology"]
}
