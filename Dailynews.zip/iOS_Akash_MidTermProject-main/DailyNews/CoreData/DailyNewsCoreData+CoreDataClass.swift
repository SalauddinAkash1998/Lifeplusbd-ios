//
//  DailyNewsCoreData+CoreDataClass.swift
//  
//
//  Created by BJIT on 18/1/23.
//
//

import Foundation
import CoreData

@objc(DailyNewsCoreData)
public class DailyNewsCoreData: NSManagedObject {

}
