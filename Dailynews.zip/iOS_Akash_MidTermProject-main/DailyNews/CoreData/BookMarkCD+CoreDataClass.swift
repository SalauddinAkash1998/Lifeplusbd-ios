//
//  BookMarkCD+CoreDataClass.swift
//  
//
//  Created by BJIT on 18/1/23.
//
//

import Foundation
import CoreData

@objc(BookMarkCD)
public class BookMarkCD: NSManagedObject {

}
