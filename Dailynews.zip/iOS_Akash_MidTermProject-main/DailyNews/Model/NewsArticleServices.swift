//
//  NewsArticleServices.swift
//  DailyNews
//
//  Created by BJIT on 12/1/23.
//

import Foundation

struct NewsArticleServices: Decodable {
//    let status: String
//    var totalResults: Int?
    var articles: [NewsArticle]?
    
}
