//
//  Constrant.swift
//  DailyNews
//
//  Created by BJIT on 19/1/23.
//

import Foundation
